<template>
  <v-ons-page>
    <p style="text-align: center">
      Change the settings.
    </p>
  </v-ons-page>
</template>



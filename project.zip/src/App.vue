<template>
  <v-ons-page>
    <v-ons-toolbar>
      <div class="center">{{ title }}</div>
    </v-ons-toolbar>

    <v-ons-tabbar position="auto"
      :tabs="tabs"
      :visible="true"
      :index.sync="activeIndex"
    >
    </v-ons-tabbar>
  </v-ons-page>
</template>

<script>
  import topPage from 'Top';
  import timeTablePage from 'TimeTable';
  import sponsorPage from 'Sponsor';

  export default {
    data() {
      return {
        activeIndex: 0,
        tabs: [
          {
            icon: this.md() ? null : 'ion-home',
            label: 'トップ',
            page: topPage
          },
          {
            icon: this.md() ? null : 'ion-ios-bell',
            label: 'TimeTable',
            page: timeTablePage
          },
          {
            icon: this.md() ? null : 'ion-ios-settings',
            label: 'bbb',
            page: sponsorPage
          }
        ]
      };
    },
    methods: {
      md() {
        return this.$ons.platform.isAndroid();
      }
    },
    computed: {
      title() {
        return this.tabs[this.activeIndex].label;
      }
    },
    components: { homePage, settingsPage, newsPage }
  }
</script>

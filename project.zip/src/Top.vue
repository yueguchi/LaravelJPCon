<template>
  <v-ons-page>
    <p style="text-align: center">
      Welcome home.
    </p>
  </v-ons-page>
</template>

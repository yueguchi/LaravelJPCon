<template>
  <v-ons-page>
    <p style="text-align: center">
      Some news here.
    </p>
  </v-ons-page>
</template>
